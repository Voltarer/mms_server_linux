#!/bin/sh
# Script doesn't work through 'modprobe'

mod_path="/lib/modules/3.18.24/kernel/drivers/net/dummy.ko"
br_name="br0"
dummy_ifacename_prefix="eth_d"

brctl addbr $br_name
rmmod $mod_path 2> /dev/null

if [ -f $mod_path ]; then
    insmod $mod_path numdummies=$1
    for i in $(seq $1)
    do
    	iface_name=$dummy_ifacename_prefix$i
		brctl addif $br_name $iface_name
	done
fi

ip link set $br_name up
brctl stp $br_name on
